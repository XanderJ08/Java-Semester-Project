package Semester_Project_with_JavaFX;

public class Test_WantToPlay_Games {
	public static void main(String[] args) {
		// Creating a WantToPlay Game to test the toString
		WantToPlay_Games WantToPlay_Game1 = new WantToPlay_Games("Walmart", "59.99", 
				"Atomic Heart", "Microsoft", "Xbox");
		
		// Printing out the details of the game using toString
		System.out.println("The details of the game that you want to play: " + 
		WantToPlay_Game1.wantToPlay_GamesString());
		
		// Creating a second WantToPlay Game 
		// to return the details one by one
		WantToPlay_Games WantToPlay_Game2 = new WantToPlay_Games("Target", "59.99");
		
		// Returning all of the details one by one
		System.out.println("\n\n\nThe place to buy the game you want: " + 
							WantToPlay_Game2.getPlaceToBuy());
		System.out.println("The price of the game that you want: " + 
							WantToPlay_Game2.getGamePrice()); 
		
	}
}

