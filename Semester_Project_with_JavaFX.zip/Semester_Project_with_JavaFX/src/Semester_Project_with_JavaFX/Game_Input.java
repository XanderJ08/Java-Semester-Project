package Semester_Project_with_JavaFX;


import java.util.Scanner;

public class Game_Input {
	public static void main(String[] args) {
		// Creating a scanner object
		Scanner input = new Scanner(System.in);
		
		// Creating a game input boolean to keep the 
		// while loop going
		boolean game_input = true;
				
		// Creating a while loop
		while (game_input = true) {
			
		// Asking the user to input the details of his game
		System.out.print("\nWhat is the name of your game?: ");
		String gameName = input.nextLine();
		
		System.out.print("What is your game's rating(E, T, M)?: ");
		String gameRating = input.nextLine();
		
		System.out.print("What is the genre of your game?: ");
		String gameGenre = input.nextLine();
		
		System.out.print("What console do you play your game on?: ");
		String gameConsole = input.nextLine();
		
		System.out.print("What is the number of players?: ");
		String numofPlayers = input.nextLine();
		
		System.out.print("When was the game released?(M/D/Y): ");
		String dateReleased = input.nextLine();

		System.out.print("Who is the developer of the game?: ");
		String gameDeveloper = input.nextLine();
		
		System.out.print("Is your game on a streaming service?"
				+ "(Enter No if no if none are available): ");
		String streamingService = input.nextLine();
		
		System.out.print("Enter a description of your game: ");
		String gameDescription = input.nextLine();
		
		// Creating a basic game to test the input functionality
		Game_ID Test_Game1 = new Game_ID(gameName, gameRating,
				gameGenre, gameConsole, numofPlayers,dateReleased, gameDeveloper,
				streamingService, gameDescription);
		
		// Returning all of the details using Print
		Test_Game1.printGame();
		
		// Asking the User which list they would put their game into
		System.out.print("\nWhat list would you enter your game into?"
				+ "\n(1) Played Games"
				+ "\n(2) Want To Play Games"
				+ "\nList Choice: ");
		double decision = input.nextDouble();
		
		// Using while to error check if they put something other than 1 or 2
		while (decision < 1 || decision > 2 ) {
			System.out.print("\nPlease enter one or two");
			System.out.print("\nWhat list would you enter your game into?"
					+ "\n(1) Played Games"
					+ "\n(2) Want To Play Games"
					+ "\nList Choice: ");
			decision = input.nextDouble();
		}
		
		// Using if to put the game into the list they chose
		// This will put their game into their played list
		if (decision == 1) {
			
			//Creating a new Scanner
			Scanner input1 = new Scanner(System.in);
			
			// Asking for their review of the game
			System.out.print("\nWhat is your review of the game?: ");
			String gameReview = input1.nextLine();
			
			// Asking for their number Rating of the game
			System.out.print("What is the number rating you give your game "
					+ "\nEnter a number (out of 10)?: ");
			String ratingnumber = input1.nextLine();
			
			// Putting the details into played games
			Played_Games Played_Game1 = new Played_Games(gameReview, ratingnumber,
					gameName, gameDeveloper);
			
			// Printing out all of the details
			Played_Game1.printPlayed_Games();
			
			// Printing out all of the total game details
			System.out.print("\n\n\nAll of the Game Details: ");
			System.out.print("\nThis game is in your Played Games List");
			System.out.print("\nGame Name: " + gameName +
					   		"\nGame Rating: " + gameRating +
					   		"\nGame Genre: " + gameGenre +
					   		"\nGame Console(s): " + gameConsole +
				   			"\nNumber of Players: " + numofPlayers +
				   			"\nDate Released (M/D/Y): " + dateReleased +
				   			"\nGame Developer: " + gameDeveloper +
				   			"\nStreaming Service (if available): " + streamingService +
				   			"\nGame Description: " + gameDescription +
				   			"\nYour review of the game: " + gameReview +
							"\nYour number rating of the game: " + ratingnumber);
			
			// Breaking out of the loop
			break;
		}
		
		// This will put the game into their want to Play list
		if (decision == 2) {
			
			//Creating a new scanner
			Scanner input2 = new Scanner(System.in);
			
			// Asking where they can buy the game
			System.out.print("\nWhere can you buy the game that you want?: ");
			String placeToBuy = input2.nextLine();
			
			// Asking how much the game is
			System.out.print("How much is the game?: ");
			String gamePrice = input2.nextLine();
			
			// Putting the details into want to play games
			WantToPlay_Games WantToPlay_Game1 = new WantToPlay_Games(placeToBuy, gamePrice, gameName,
					gameDeveloper, gameConsole);
			
			// Printing out all of the details
			WantToPlay_Game1.printWantToPlay_Games();
			
			// Printing out all of the total game Details
			System.out.print("\n\n\nAll of the Game Details: ");
			System.out.print("\nThis game is in your Want To Play Games List");
			System.out.print("\nGame Name: " + gameName +
					   		"\nGame Rating: " + gameRating +
					   		"\nGame Genre: " + gameGenre +
					   		"\nGame Console(s): " + gameConsole +
				   			"\nNumber of Players: " + numofPlayers +
				   			"\nDate Released (M/D/Y): " + dateReleased +
				   			"\nGame Developer: " + gameDeveloper +
				   			"\nStreaming Service (if available): " + streamingService +
				   			"\nGame Description: " + gameDescription +
				   			"\nPlace To Buy: " + placeToBuy +
							"\nGame Price: " + gamePrice);
			
			// Breaking out of the loop
			break;
			}
		}
	}
}
