package Semester_Project_with_JavaFX;

// Importing the various modules that I will need
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.GridPane;
import javafx.scene.text.*;
import javafx.geometry.Pos;
import javafx.geometry.Insets;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import java.util.ArrayList;

public class Semester_Project_Main_JavaFX extends Application{
	
	// Creating ArrayList to hold the information that the
	// user wants to put in.
	ArrayList<String> WantToPlayGames = new ArrayList<>();
	ArrayList<String> PlayedGames = new ArrayList<>();
	ArrayList<String> GameID = new ArrayList<>();
	
	@Override // Overriding the start method in the application class
	public void start (Stage gameStage) {
		// Creating the UI
		GridPane gamePane = new GridPane();
		gamePane.setVgap(5);
		gamePane.setHgap(5);
		gamePane.add(new Label("Game Name: "), 0, 0);
		TextField tfGameName = new TextField();
		gamePane.add(tfGameName, 1, 0);
		gamePane.add(new Label("ESRB Rating: "), 0, 1);
		TextField tfGameRating = new TextField();
		tfGameRating.setPromptText("Example: E, T, M");
		gamePane.add(tfGameRating, 1, 1);
		gamePane.add(new Label("Game Genre: "), 0, 2);
		TextField tfGameGenre = new TextField();
		gamePane.add(tfGameGenre, 1, 2);
		gamePane.add(new Label("Game Console: "), 0, 3);
		TextField tfGameConsole = new TextField();
		gamePane.add(tfGameConsole, 1, 3);
		gamePane.add(new Label("Number of Players: "), 0, 4);
		TextField tfNumOfPlayers = new TextField();
		gamePane.add(tfNumOfPlayers, 1, 4);
		gamePane.add(new Label("Date Released: "), 0, 5);
		TextField tfDateReleased = new TextField();
		tfDateReleased.setPromptText("M/D/Y");
		gamePane.add(tfDateReleased, 1, 5);
		gamePane.add(new Label("Game Developer: "), 0, 6);
		TextField tfGameDeveloper = new TextField();
		gamePane.add(tfGameDeveloper, 1, 6);
		gamePane.add(new Label("Streaming Service: "), 0, 7);
		TextField tfStreamingService = new TextField();
		tfStreamingService.setPromptText("Enter N/A if there are none");
		gamePane.add(tfStreamingService, 1, 7);
		gamePane.add(new Label("Game Description: "), 0, 8);
		TextField tfGameDescription = new TextField();
		gamePane.add(tfGameDescription, 1, 8);
		
		// Creating Additional TextFields that I will need
		// later in the program
		TextField tfPersonalReview = new TextField();
		TextField tfNumberRating = new TextField();
		TextField tfPlaceToBuy = new TextField();
		TextField tfGamePrice = new TextField();
		
		// Creating all of the buttons that will be used
		// by the user to navigate to different places
		Button btSubmitGame = new Button("Submit Game");
		Button btPutIntoPlayedGames = new Button("Put In Your Played List");
		Button btPutIntoWantToPlayGames = new Button("Put In Your Want To Play List");
		Button btAddToPlayedGamesList = new Button("Add to Played Games List");
		Button btAddToWantToPlayGamesList = new Button("Add to Want To Play List");
		Button btExitProgram = new Button("Exit");
		Button btViewGameList = new Button("View Your Game List");
		Button btAddNewGame = new Button("Add Another Game");
		Button btViewPlayedGamesList = new Button("View Played Games List");
		Button btViewWantToPlayGamesList = new Button("View Want To Play Games List");
		
		// Adding buttons to the end of the first stage
		gamePane.add(btExitProgram, 0, 9);
		gamePane.add(btSubmitGame, 1, 9);
		
		// Setting the UI properties
		gamePane.setAlignment(Pos.CENTER);
		tfGameName.setAlignment(Pos.BOTTOM_RIGHT);
		tfGameRating.setAlignment(Pos.BOTTOM_RIGHT);
		tfGameGenre.setAlignment(Pos.BOTTOM_RIGHT);
		tfGameConsole.setAlignment(Pos.BOTTOM_RIGHT);
		tfNumOfPlayers.setAlignment(Pos.BOTTOM_RIGHT);
		tfDateReleased.setAlignment(Pos.BOTTOM_RIGHT);
		tfGameDeveloper.setAlignment(Pos.BOTTOM_RIGHT);
		tfStreamingService.setAlignment(Pos.BOTTOM_RIGHT);
		tfGameDescription.setAlignment(Pos.BOTTOM_RIGHT);
		btSubmitGame.setAlignment(Pos.BASELINE_RIGHT);
		btExitProgram.setAlignment(Pos.CENTER_RIGHT);
		gamePane.setPadding(new Insets(10, 10, 10, 10));
		
		// Creating a scene and placing it in the stage
			Scene gameScene = new Scene(gamePane);
			gameStage.setTitle("Game Information"); // Setting the title
			gameStage.setScene(gameScene); // Placing the scene on the stage
			gameStage.show(); // Displaying the stage
		
		// Processing the events
		btSubmitGame.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				
				// Bringing in the String so that they can be
				// put into GameID
				String gameNameRead = tfGameName.getText();
				String gameDeveloperRead = tfGameDeveloper.getText();
				String gameConsoleRead = tfGameConsole.getText();
				String gameRatingRead = tfGameRating.getText();
				String gameGenreRead = tfGameGenre.getText();
				String numOfPlayersRead = tfNumOfPlayers.getText();
				String dateReleasedRead = tfDateReleased.getText();
				String streamingServiceRead = tfStreamingService.getText();
				String gameDescriptionRead = tfGameDescription.getText();
				
				// Creating a GameID out of the values that
				// the user put in
				Game_ID Game_GameID = new Game_ID(gameNameRead, gameRatingRead, gameGenreRead,
						gameConsoleRead, numOfPlayersRead, dateReleasedRead, gameDeveloperRead, 
						streamingServiceRead, gameDescriptionRead);
				
				// Adding the Game_ID.toString to an arraylist named
				// GameID
				GameID.add(Game_GameID.toString());
				
				// Setting up the UI of the Scene
				GridPane gameListDecisionPane = new GridPane();
				gameListDecisionPane.setVgap(5);
				gameListDecisionPane.setHgap(5);
				Label label = new Label("Please select a list to put your game into: ");
				label.setFont(Font.font("Sans Serif", FontWeight.BOLD, 20));
				gameListDecisionPane.add(label, 0, 0);
				gameListDecisionPane.add(btPutIntoPlayedGames, 0, 1);
				gameListDecisionPane.add(btPutIntoWantToPlayGames, 1, 1);
				
				// Setting up the Alignment of the various things
				// in the Pane.
				gameListDecisionPane.setAlignment(Pos.CENTER);
				btPutIntoPlayedGames.setAlignment(Pos.CENTER);
				btPutIntoWantToPlayGames.setAlignment(Pos.CENTER);
				
				// Creating the scene and placing it on the stage
				Scene decisionScene = new Scene(gameListDecisionPane);
				gameStage.setTitle("List Decision");
				gameStage.setScene(decisionScene);
				gameStage.show();
				
			}
		});
		
		// Creating the function of the button:
		// Put Into Played Games
		btPutIntoPlayedGames.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				
				// Bringing the various information that the
				// program needs
				String gameNameRead = tfGameName.getText();
				String gameDeveloperRead = tfGameDeveloper.getText();
				
				// Creating the UI of the Scene
				GridPane playedGamePane = new GridPane();
				playedGamePane.setVgap(5);
				playedGamePane.setHgap(5);
				playedGamePane.add(new Label("Game Name: "), 0, 0);
				playedGamePane.add(new Label(gameNameRead), 1, 0);
				playedGamePane.add(new Label("Game Developer: "), 0, 1);
				playedGamePane.add(new Label(gameDeveloperRead), 1, 1);
				playedGamePane.add(new Label("Personal Review: "), 0, 2);
				playedGamePane.add(tfPersonalReview, 1, 2);
				playedGamePane.add(new Label("Number Review: "), 0, 3);
				playedGamePane.add(tfNumberRating, 1, 3);
				playedGamePane.add(btAddToPlayedGamesList, 1, 4);
				
				// Setting up the alignments of the Pane
				playedGamePane.setPadding(new Insets(10, 10, 10, 10));
				playedGamePane.setAlignment(Pos.CENTER);
				tfGameName.setAlignment(Pos.BOTTOM_RIGHT);
				tfGameDeveloper.setAlignment(Pos.BOTTOM_RIGHT);
				tfPersonalReview.setAlignment(Pos.BOTTOM_RIGHT);
				tfNumberRating.setAlignment(Pos.BOTTOM_RIGHT);
				btAddToPlayedGamesList.setAlignment(Pos.BOTTOM_RIGHT);
				
				// Creating the scene and placing it on the stage
				Scene playedGamesScene = new Scene(playedGamePane);
				gameStage.setTitle("Played Games Info");
				gameStage.setScene(playedGamesScene);
				gameStage.show();
			}
		});
		
		// Creating the function of the button: 
		// Submit To Played Games
		btAddToPlayedGamesList.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				// Creating a new GridPane
				GridPane PlayedGamesListPane = new GridPane();
				
				// Bringing in the necessary information that will be needed
				String gameNameRead = tfGameName.getText();
				String gameDeveloperRead = tfGameDeveloper.getText();
				String personalReviewRead = tfPersonalReview.getText();
				String numberRatingRead = tfNumberRating.getText();
				
				// Putting the info from the user into Played Games
				Played_Games Game_PlayedGames = new Played_Games(personalReviewRead, numberRatingRead,
						gameNameRead, gameDeveloperRead);
				
				// Adding that information to Array List named PlayedGames
				PlayedGames.add(Game_PlayedGames.playedGames_toString());
				
				// Turning the Array List to a String so the user can see
				// their list
				String PlayedGamesList = PlayedGames.toString();
				
				// Creating a scrollpane so the user can scroll through the list if
				// thier list becomes too large to see at once
				ScrollPane scrollPane = new ScrollPane();
				
				// Setting up the UI
				PlayedGamesListPane.setVgap(5);
				PlayedGamesListPane.setHgap(5);
				PlayedGamesListPane.add(new Label("Played Games List: "), 0, 0);
				PlayedGamesListPane.add(new Label(PlayedGamesList), 0, 1);
				PlayedGamesListPane.add(btViewGameList, 0, 2);
				PlayedGamesListPane.add(btExitProgram, 1, 2);
				PlayedGamesListPane.add(btAddNewGame, 0, 3);
				
				// Setting up the Alignment
				PlayedGamesListPane.setPadding(new Insets(10, 10, 10, 10));
				PlayedGamesListPane.setAlignment(Pos.CENTER);
				btViewGameList.setAlignment(Pos.BOTTOM_LEFT);
				btExitProgram.setAlignment(Pos.BOTTOM_RIGHT);
				btAddNewGame.setAlignment(Pos.BOTTOM_CENTER);
				
				// Setting up the Scroll Pane with the Gridpane we created
				scrollPane.setContent(PlayedGamesListPane);
				
				// Setting up the preffered size of the Pane
				scrollPane.setPrefSize(400, 300);
				
				// Setting up the details of the scroll bar
				scrollPane.setFitToWidth(true);
		        scrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.ALWAYS);
		        
		        // Setting up the scene and placing it on the stage
				Scene playedGamesListScene = new Scene(scrollPane);
				gameStage.setTitle("Played Games List");
				gameStage.setScene(playedGamesListScene);
				gameStage.show();
			}
		});
		
		// Creating the function of the button:
		// Put Into Want To Play Games
		btPutIntoWantToPlayGames.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				// Bringing in the various information that
				// will be needed
				String gameNameRead = tfGameName.getText();
				String gameDeveloperRead = tfGameDeveloper.getText();
				String gameConsoleRead = tfGameConsole.getText();
				
				// Creating the GridPane and setting up the UI
				GridPane wantToPlayGamePane = new GridPane();
				wantToPlayGamePane.setVgap(5);
				wantToPlayGamePane.setHgap(5);
				wantToPlayGamePane.add(new Label("Game Name: "), 0, 0);
				wantToPlayGamePane.add(new Label(gameNameRead), 1, 0);
				wantToPlayGamePane.add(new Label("Game Developer: "), 0, 1);
				wantToPlayGamePane.add(new Label(gameDeveloperRead), 1, 1);
				wantToPlayGamePane.add(new Label("Game Console"), 0, 2);
				wantToPlayGamePane.add(new Label(gameConsoleRead), 1, 2);
				wantToPlayGamePane.add(new Label("Place To Buy: "), 0, 3);
				wantToPlayGamePane.add(tfPlaceToBuy, 1, 3);
				wantToPlayGamePane.add(new Label("Game Price: "), 0, 4);
				wantToPlayGamePane.add(tfGamePrice, 1, 4);
				wantToPlayGamePane.add(btAddToWantToPlayGamesList, 1, 5);
				
				// Setting up the Alignment
				wantToPlayGamePane.setPadding(new Insets(10, 10, 10, 10));
				wantToPlayGamePane.setAlignment(Pos.CENTER);
				tfGameName.setAlignment(Pos.BOTTOM_RIGHT);
				tfGameDeveloper.setAlignment(Pos.BOTTOM_RIGHT);
				tfGameConsole.setAlignment(Pos.BOTTOM_RIGHT);
				tfPlaceToBuy.setAlignment(Pos.BOTTOM_RIGHT);
				tfGamePrice.setAlignment(Pos.BOTTOM_RIGHT);
				btAddToWantToPlayGamesList.setAlignment(Pos.BOTTOM_RIGHT);
				
				// Creating the scene and placing it on the Stage
				Scene wantToPlayGamesScene = new Scene(wantToPlayGamePane);
				gameStage.setTitle("Want To Play Games Info");
				gameStage.setScene(wantToPlayGamesScene);
				gameStage.show();
			}
		});
		
		// Creating the function of the button:
		// Submit to Want To Play Games
		btAddToWantToPlayGamesList.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				
				// Bringing in the Various information needed.
				String gameNameRead = tfGameName.getText();
				String gameDeveloperRead = tfGameDeveloper.getText();
				String gameConsoleRead = tfGameConsole.getText();
				String placeToBuyRead = tfPlaceToBuy.getText();
				String gamePriceRead = tfGamePrice.getText();
				
				// Placing the information into WantToPlay_Games
				WantToPlay_Games Game_WantToPlayGames = new WantToPlay_Games(placeToBuyRead, gamePriceRead,
						gameNameRead, gameDeveloperRead, gameConsoleRead);
				
				// Adding the information to a Arraylist named
				// WantToPlayGames
				WantToPlayGames.add(Game_WantToPlayGames.wantToPlay_GamesString());
				String WantToPlayGamesList = WantToPlayGames.toString();
				
				// Creating a new ScrollPane();
				ScrollPane scrollPane = new ScrollPane();
				
				// Creating the GridPane and it's UI
				GridPane WantToPlayGamesListPane = new GridPane();
				WantToPlayGamesListPane.setVgap(5);
				WantToPlayGamesListPane.setHgap(5);
				WantToPlayGamesListPane.add(new Label("Want To Play Games List: "), 0, 0);
				WantToPlayGamesListPane.add(new Label(WantToPlayGamesList), 0, 1);
				WantToPlayGamesListPane.add(btViewGameList, 0, 2);
				WantToPlayGamesListPane.add(btExitProgram, 1, 2);
				WantToPlayGamesListPane.add(btAddNewGame, 0, 3);
				
				// Setting up the Alignment of the GridPane
				WantToPlayGamesListPane.setPadding(new Insets(10, 10, 10, 10));
				WantToPlayGamesListPane.setAlignment(Pos.CENTER);
				btViewGameList.setAlignment(Pos.BOTTOM_LEFT);
				btExitProgram.setAlignment(Pos.BOTTOM_RIGHT);
				
				// Putting the GridPane into the scrollPane
				scrollPane.setContent(WantToPlayGamesListPane);
				scrollPane.setPrefSize(400, 300);
				
				// Setting up the details of the scrollPane
				scrollPane.setFitToWidth(true);
		        scrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.ALWAYS);
				
				// Creating the scene and placing it on the Stage
				Scene WantToPlayGamesListScene = new Scene(scrollPane);
				gameStage.setTitle("Want To Play Games List");
				gameStage.setScene(WantToPlayGamesListScene);
				gameStage.show();
			}
		});
		
		// Creating the function of the button:
		// Exit Program
		btExitProgram.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				// Exiting the program
				Platform.exit();
			}
		});
		
		// Creating the function of the button:
		// Add Another Game
		btAddNewGame.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				// Clearing all of the text fields
				// so the user can add more games
				tfGameName.clear(); 
				tfGameRating.clear();
				tfGameGenre.clear();
				tfGameConsole.clear();
				tfNumOfPlayers.clear();
				tfDateReleased.clear();
				tfGameDeveloper.clear();
				tfStreamingService.clear();
				tfGameDescription.clear();
				tfPersonalReview.clear();
				tfNumberRating.clear();
				tfPlaceToBuy.clear();
				tfGamePrice.clear();
				
				// Sending the User back to the
				// Create Game Page
				gameStage.setTitle("Game Information"); // Setting the title
				gameStage.setScene(gameScene); // Placing the scene on the stage
				gameStage.show();
			}
		});
		
		// Creating the function of the button:
		// ViewPlayedGamesList
		btViewPlayedGamesList.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				// Turning the Array List into a String
				String PlayedGamesList = PlayedGames.toString();
				
				// Creating a new ScrollPane
				ScrollPane scrollPane = new ScrollPane();
				
				// Creating a new GridPane
				GridPane PlayedGamesListPane = new GridPane();
				
				// Setting the Prefereed size of the Pane
				PlayedGamesListPane.setPrefSize(PlayedGamesListPane.getLayoutBounds().getWidth(),
						PlayedGamesListPane.getLayoutBounds().getHeight());
				
				// Setting up the UI of the Pane
				PlayedGamesListPane.setVgap(5);
				PlayedGamesListPane.setHgap(5);
				PlayedGamesListPane.add(new Label("Played Games List: "), 0, 0);
				PlayedGamesListPane.add(new Label(PlayedGamesList), 0, 1);
				PlayedGamesListPane.add(btViewGameList, 0, 2);
				PlayedGamesListPane.add(btExitProgram, 1, 2);
				PlayedGamesListPane.add(btAddNewGame, 0, 3);
				
				// Setting up the alignment
				PlayedGamesListPane.setPadding(new Insets(10, 10, 10, 10));
				PlayedGamesListPane.setAlignment(Pos.CENTER);
				btViewGameList.setAlignment(Pos.BOTTOM_LEFT);
				btExitProgram.setAlignment(Pos.BOTTOM_RIGHT);
				btAddNewGame.setAlignment(Pos.BOTTOM_CENTER);
				
				// Adding the GridPane into the scrollPane
				scrollPane.setContent(PlayedGamesListPane);
				scrollPane.setPrefSize(400, 300);
				
				// Setting up the details of the scrollPane
				scrollPane.setFitToWidth(true);
		        scrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.ALWAYS);
		        
		        // Creating the scene and placing it on the stage
				Scene playedGamesListScene = new Scene(scrollPane);
				gameStage.setTitle("Played Games List View");
				gameStage.setScene(playedGamesListScene);
				gameStage.show();		
			}
		});
		
		// Creating the function of the button:
		// ViewWantToPlayGamesList
		btViewWantToPlayGamesList.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				// Creating a String of the Array List named
				// WantToPlayGames
				String WantToPlayGamesList = WantToPlayGames.toString();
				
				// Creating a GridPane and its UI
				GridPane WantToPlayGamesListPane = new GridPane();
				WantToPlayGamesListPane.setVgap(5);
				WantToPlayGamesListPane.setHgap(5);
				WantToPlayGamesListPane.add(new Label("Want To Play Games List: "), 0, 0);
				WantToPlayGamesListPane.add(new Label(WantToPlayGamesList), 0, 1);
				WantToPlayGamesListPane.add(btViewGameList, 0, 2);
				WantToPlayGamesListPane.add(btExitProgram, 1, 2);
				
				// Setting up the Alignment
				WantToPlayGamesListPane.setPadding(new Insets(10, 10, 10, 10));
				WantToPlayGamesListPane.setAlignment(Pos.CENTER);
				btViewGameList.setAlignment(Pos.BOTTOM_LEFT);
				btExitProgram.setAlignment(Pos.BOTTOM_RIGHT);
				
				// Setting up the Max Height of the Pane
				WantToPlayGamesListPane.setMaxHeight(400);
				
				// Creating a Scrollpane and putting the GridPane in it
				ScrollPane scrollPane = new ScrollPane(WantToPlayGamesListPane);
				scrollPane.setPrefSize(400, 300);
				
				// Setting up the details of the ScrollPane
				scrollPane.setFitToWidth(true);
		        scrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.ALWAYS);
		        
				// Creaing the scene and placing it on the stage
				Scene WantToPlayGamesListScene = new Scene(scrollPane);
				gameStage.setTitle("Want To Play Games List");
				gameStage.setScene(WantToPlayGamesListScene);
				gameStage.show();
			}
		});
		
		// Creating the function of the button:
		// VIewGameList
		btViewGameList.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				// Creating a string of the Array List named
				// GameID
				String GameIDList = GameID.toString();
				
				// Creating a ScrollPane
				ScrollPane scrollPane = new ScrollPane();
				
				// Creating a gridpane and setting up the UI
				GridPane FullGameDetailsPane = new GridPane();
				FullGameDetailsPane.setVgap(5);
				FullGameDetailsPane.setHgap(5);
				FullGameDetailsPane.add(new Label("Full Game Details List: "), 0, 0);
				FullGameDetailsPane.add(new Label(GameIDList), 0, 1);
				FullGameDetailsPane.add(btExitProgram, 0, 2);
				FullGameDetailsPane.add(btAddNewGame, 1, 2);
				FullGameDetailsPane.add(btViewPlayedGamesList, 0, 3);
				FullGameDetailsPane.add(btViewWantToPlayGamesList, 1, 3);
				
				// Setting up the Alignment of the Pane
				FullGameDetailsPane.setPadding(new Insets(10, 10, 10, 10));
				FullGameDetailsPane.setAlignment(Pos.CENTER);
				btExitProgram.setAlignment(Pos.BOTTOM_RIGHT);
				btAddNewGame.setAlignment(Pos.CENTER);
				
				// Adding the GridPane to the ScrollPane
				scrollPane.setContent(FullGameDetailsPane);
				scrollPane.setPrefSize(400, 300);
				
				// Setting up the details of the ScrollPane
				scrollPane.setFitToWidth(true);
		        scrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.ALWAYS);
				
		        // Creating the scene and placing it on the stage
				Scene FullGamesDetailsScene = new Scene(scrollPane);
				gameStage.setTitle("Full Game Details");
				gameStage.setScene(FullGamesDetailsScene);
				gameStage.show();		
			}
		});
		
	}
}
		