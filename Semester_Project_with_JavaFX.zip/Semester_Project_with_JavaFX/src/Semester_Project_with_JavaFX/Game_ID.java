package Semester_Project_with_JavaFX;

public class Game_ID {
	private String gameName;
	private String gameRating;
	private String gameGenre;
	private String gameConsole;
	private String numofPlayers;
	private String dateReleased;
	private String gameDeveloper;
	private String streamingService;
	private String gameDescription;
	
	//Constructing a defualt Game_ID
	public Game_ID() {
		}
	
	// Constructing a Game_ID with the specified values:
	// Game ID, Game Name, Game Rating, Game Genre, Game Console,
	// Number of Players, Date Released, Game Developer,
	// Streaming Service, and Game Description
	public Game_ID(String gameName, String gameRating,
			String gameGenre, String gameConsole, String numofPlayers, 
			String dateReleased,String gameDeveloper, String streamingService, 
			String gameDescription) {
		this.gameName = gameName;
		this.gameRating = gameRating;
		this.gameGenre = gameGenre;
		this.gameConsole = gameConsole;
		this.numofPlayers = numofPlayers;
		this.dateReleased = dateReleased;
		this.gameDeveloper = gameDeveloper;
		this.streamingService = streamingService;
		this.gameDescription = gameDescription;
	}
	
	// Returning the game name
	public String getGamename() {
		return gameName;
	}
	
	// Setting the game name
	public void setGamename(String gameName) {
		this.gameName = gameName;
	}
	
	// Returning the game rating
	public String getRating() {
		return gameRating;
	}
	
	// Returning the game genre
	public String getGenre() {
		return gameGenre;
	}
	
	// Returning the game console
	public String getConsole() {
		return gameConsole;
	}
	
	// Setting the game console
	public void setConsole(String gameConsole) {
		this.gameConsole = gameConsole;
	}
	
	// Returning the number of players
	public String getNumofPlayers() {
		return numofPlayers;
	}
	
	// Returning the Date Released
	public String getDateReleased(){
		return dateReleased;	
	}
	
	// Returning the game developer
	public String getDeveloper() {
		return gameDeveloper;
	}
	
	// Setting the game developer
	public void setDeveloper(String gameDeveloper) {
		this.gameDeveloper = gameDeveloper;
	}
	
	// Returning the streaming service
	public String getStreamingService() {
		return streamingService;
	}
	
	// Returning the game description
	public String getDescription() {
		return gameDescription;
	}
	
	// Returning a string representation of this object
	public String toString() {
		return 	   "\nGame Name: " + gameName +
				   "\nGame Rating: " + gameRating +
				   "\nGame Genre: " + gameGenre +
				   "\nGame Console(s): " + gameConsole +
				   "\nNumber of Players: " + numofPlayers +
				   "\nDate Released (M/D/Y): " + dateReleased +
				   "\nGame Developer: " + gameDeveloper +
				   "\nStreaming Service (if available): " + streamingService +
				   "\nGame Description: " + gameDescription + "\n";
	}
		
	public void printGame() {
		System.out.println("\nGame Name: " + gameName +
				   "\nGame Rating: " + gameRating +
				   "\nGame Genre: " + gameGenre +
				   "\nGame Console(s): " + gameConsole +
				   "\nNumber of Players: " + numofPlayers +
				   "\nDate Released (M/D/Y): " + dateReleased +
				   "\nGame Developer: " + gameDeveloper +
				   "\nStreaming Service (if available): " + streamingService +
				   "\nGame Description: " + gameDescription);
	}
	
}
