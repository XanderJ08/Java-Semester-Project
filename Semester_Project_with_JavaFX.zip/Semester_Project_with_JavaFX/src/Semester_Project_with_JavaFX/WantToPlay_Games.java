package Semester_Project_with_JavaFX;

// Extending Game_ID with WantToPlay_Games
public class WantToPlay_Games extends Game_ID {
	private String placeToBuy;
	private String gamePrice;
	
	// Creating a default Want To Play Games
	public WantToPlay_Games() {
	}
	
	// Creating a Want To Play Games with 
	// place to buy and game price
	public WantToPlay_Games(String placeToBuy,
							String gamePrice) {
		this.placeToBuy = placeToBuy;
		this.gamePrice = gamePrice;
	}
	
	// Creating a want to play games with
	// place to buy, game price, game name, 
	// game developer, and game console
	public WantToPlay_Games(String placeToBuy,
			String gamePrice,String gameName, 
			String gameDeveloper,String gameConsole) {
		this.placeToBuy = placeToBuy;
		this.gamePrice = gamePrice;
		setGamename(gameName);
		setDeveloper(gameDeveloper);
		setConsole(gameConsole);	
	}
	
	// Returning Place To Buy
	public String getPlaceToBuy() {
		return placeToBuy;
	}
	
	// Returning game price
	public String getGamePrice() {
		return gamePrice;
	}
	
	// Using toString to return all of the details
	public String wantToPlay_GamesString() {
		return("\nGame Name: " + getGamename() +
		       "\nGame Developer: " + getDeveloper() +
		       "\nGame Console: " + getConsole() +
		       "\nPlace to Buy: " + getPlaceToBuy() +
		       "\nThe Price of your game: " + "$" + getGamePrice() + "\n");
		}
	
	// Using Print to print all of the details
	public void printWantToPlay_Games() {
		System.out.print("\nGame Name: " + getGamename() +
		                 "\nGame Developer: " + getDeveloper() +
		                 "\nGame Console: " + getConsole() +
		                 "\nPlace to Buy: " + getPlaceToBuy() +
		                 "\nThe Price of your game: " + getGamePrice());
	}
	

}
