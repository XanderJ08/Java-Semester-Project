package Semester_Project_with_JavaFX;

public class Test_Game_ID {
	public static void main(String [] args) {
		// Creating a Game to Test the ToString function
		Game_ID Game_ID0 = new Game_ID("Battle for Bikini Bottom", "E10+", 
				"Action, Adventure", "Xbox, PS2", "1", "Sometime in 2004", 
				"THQ", "NA" , "Big Spongebob Adventure");
		
		// Returning all of the details using toString
		System.out.println("The details of the game: " + Game_ID0.toString());
		
		
		// Creating a second game to print the get functions for all of the details
		Game_ID Game_ID1 = new Game_ID("Ocarina of Time", "Teen", "Action, Fantasy",
				"Nintendo 64", "1", "1999", "Nintendo", "Nintendo Online", "One of the best "
				+ "games of all time");
		
		// Returning all of the details line by line
		System.out.println("\n\n\nName: " + Game_ID1.getGamename());
		System.out.println("Rating: " + Game_ID1.getRating());
		System.out.println("Genre: " + Game_ID1.getGenre());
		System.out.println("Number of Players: " + Game_ID1.getNumofPlayers());
		System.out.println("Release Date: " + Game_ID1.getDateReleased());
		System.out.println("Developer: " + Game_ID1.getDeveloper());
		System.out.println("Streaming Service Availability: " + Game_ID1.getStreamingService());
		System.out.println("Description: " + Game_ID1.getDescription());
	}

}
