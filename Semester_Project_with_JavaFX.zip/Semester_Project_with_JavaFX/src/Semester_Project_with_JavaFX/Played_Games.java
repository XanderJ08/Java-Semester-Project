package Semester_Project_with_JavaFX;

// Extending Game_ID by Played Games
public class Played_Games extends Game_ID {
	private String personalReview;
	private String numberRating;
	
	// Creating a default played_games
	public Played_Games() {
	}
	
	// Constructing played_games with 
	// rating and review
	public Played_Games(String personalReview, 
			String numberRating) {
		this.numberRating = numberRating;
		this.personalReview = personalReview;
	}
	
	// Constructing a played_games with
	// rating, review, game name, and 
	// gameDeveloper
	public Played_Games(String personalReview, 
			String numberRating, String gameName, 
			String gameDeveloper) {	
		this.numberRating = numberRating;
		this.personalReview = personalReview;
		setGamename(gameName);
		setDeveloper(gameDeveloper);
	}
	
	// Returning the Rating
	public String getpersonalReview() {
		return personalReview;
	}
	
	// Returning the Review
	public String getnumberRating() {
		return numberRating;
	}
	
	// Using toString to return all of the details
	public String playedGames_toString() {
					return("\nGame Name: " + getGamename() +
						   "\nGame Developer: " + getDeveloper() +
						   "\nYour Personal Review: " + getpersonalReview() +
						   "\nYour Number Rating: " + getnumberRating() + " out of 10" + "\n");
	}
	
	// Printing out all of the details
	public void printPlayed_Games() {
		System.out.print("\nGame Name: " + getGamename() +
						 "\nGame Developer: " + getDeveloper() +
						 "\nYour Personal Review: " + getpersonalReview() +
						 "\nYour Number Rating: " + getnumberRating() + " out of 10");
	}

}
