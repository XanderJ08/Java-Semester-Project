package Semester_Project_with_JavaFX;

public class Test_Played_Games {
	public static void main(String[] args) {
		// Creating a played_Games to test the toString
		Played_Games Played_Games = new Played_Games("I really like it", "9", 
				"Super Mario Odessey", "Nintendo");
		
		// Returning the details using toString
		System.out.println("The details of the game you have played are: " 
		+ Played_Games.playedGames_toString());
		
		// Creating a second played_games to return the details individually
		Played_Games Played_Games1 = new Played_Games("It's alright.", "9");
		
		// Returning all of the details individually
		System.out.println("\n\n\nThe review you gave your game: " + 
		Played_Games1.getpersonalReview());
		System.out.println("The Number Rating you gave your game: " +
		Played_Games1.getnumberRating() + " out of 10");
		
	}
}
